var MyName = 'Vitoria';
var FavNumberInteger = 8888;
var FavNumberString = '8888';
var x = [true];
var MyNameLetters = [
'V',
'I',
'T',
'O',
'R',
'I',
'A'
];

var DataTypes = [
18,
true,
'raspberries'
];

var firstName = "Vitoria";
var lastName  = "DiIulio";

var fullName  = firstName + lastName;

console.log (40+60)

var firstItem = MyNameLetters[0];
var lastItem = MyNameLetters[MyNameLetters.length - 1];

var MarryPopins = 'supercalifragilisticexpialidocious';

var y = MarryPopins.length;


